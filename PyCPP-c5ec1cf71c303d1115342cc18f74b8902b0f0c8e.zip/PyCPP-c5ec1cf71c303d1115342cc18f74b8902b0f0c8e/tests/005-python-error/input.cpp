#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
#py x = non_exstsnt_var
    return 0;
}

